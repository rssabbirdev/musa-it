import './index.css';

export default function LogoSpinner() {
    return (
		<div className='loading-spinner-body'>
			<div className='loading-spinner'></div>
		</div>
	);
}
