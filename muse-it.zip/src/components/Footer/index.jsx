export default function Footer() {
    return (
		<div className='bg-black p-10'>
			<p className='text-sm'>© 2023-2024 MUSE-IT. All Rights Reserved.</p>
		</div>
	);
}
